using AtomUI.Controls;

namespace AtomUIGallery.ShowCases.Collapse;

public partial class CollapseBehaviorShowCase : GalleryReactiveUserControl<CollapseViewModel>
{
    public CollapseBehaviorShowCase()
    {
        InitializeComponent();
    }

    private void HandleExpandButtonPosOptionCheckedChanged(object? sender, OptionCheckedChangedEventArgs args)
    {
        if (DataContext is CollapseViewModel viewModel)
        {
            viewModel.HandleExpandButtonPosOptionCheckedChanged(sender, args);
        }
    }
}
