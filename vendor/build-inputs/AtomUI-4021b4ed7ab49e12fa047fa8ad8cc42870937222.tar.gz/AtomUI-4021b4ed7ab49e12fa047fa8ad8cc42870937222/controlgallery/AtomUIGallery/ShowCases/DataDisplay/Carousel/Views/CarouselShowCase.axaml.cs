using AtomUI.Controls;
using AtomUI.Desktop.Controls;

namespace AtomUIGallery.ShowCases.Carousel;

public partial class CarouselShowCase : GalleryReactiveUserControl<CarouselViewModel>
{
    public const string LanguageId = nameof(CarouselShowCase);

    public CarouselShowCase()
    {
        InitializeComponent();
    }

    public void HandlePositionOptionChanged(object? sender, OptionCheckedChangedEventArgs args)
    {
        if (DataContext is CarouselViewModel viewModel)
        {
            if (args.Index == 0)
            {
                viewModel.PaginationPosition = CarouselPaginationPosition.Top;
            }
            else if (args.Index == 1)
            {
                viewModel.PaginationPosition = CarouselPaginationPosition.Bottom;
            }
            else if (args.Index == 2)
            {
                viewModel.PaginationPosition = CarouselPaginationPosition.Left;
            }
            else
            {
                viewModel.PaginationPosition = CarouselPaginationPosition.Right;
            }
        }

    }
}
