using AtomUI.Controls;
using ReactiveUI;

namespace AtomUIGallery.ShowCases.Statistic;

public class StatisticViewModel : ReactiveObject, IRoutableViewModel
{
    public static EntityKey ID = "Statistic";

    public IScreen HostScreen { get; }

    public string? UrlPathSegment => ID.ToString();

    private double _values = 112893;

    public double Values
    {
        get => _values;
        set => this.RaiseAndSetIfChanged(ref _values, value);
    }

    private DateTime _deadline;

    public DateTime Deadline
    {
        get => _deadline;
        set => this.RaiseAndSetIfChanged(ref _deadline, value);
    }

    private DateTime _tenSecondsLater;

    public DateTime TenSecondsLater
    {
        get => _tenSecondsLater;
        set => this.RaiseAndSetIfChanged(ref _tenSecondsLater, value);
    }

    private DateTime _before;

    public DateTime Before
    {
        get => _before;
        set => this.RaiseAndSetIfChanged(ref _before, value);
    }

    public StatisticViewModel(IScreen screen)
    {
        HostScreen = screen;
    }

}
