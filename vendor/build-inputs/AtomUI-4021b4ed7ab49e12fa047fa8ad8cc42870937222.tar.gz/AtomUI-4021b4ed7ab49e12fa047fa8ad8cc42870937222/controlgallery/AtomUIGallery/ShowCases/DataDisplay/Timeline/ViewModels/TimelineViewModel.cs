using AtomUI.Controls;
using ReactiveUI;

namespace AtomUIGallery.ShowCases.Timeline;

public class TimelineViewModel : ReactiveObject, IRoutableViewModel
{
    public static EntityKey ID = "Timeline";

    public IScreen HostScreen { get; }

    public string UrlPathSegment { get; } = ID.ToString();

    private bool _reverseTimelineIsReverse;
    private TimelineMode _selectedTimelineMode = TimelineMode.Start;

    public bool ReverseTimelineIsReverse
    {
        get => _reverseTimelineIsReverse;
        set => this.RaiseAndSetIfChanged(ref _reverseTimelineIsReverse, value);
    }

    public TimelineMode SelectedTimelineMode
    {
        get => _selectedTimelineMode;
        set => this.RaiseAndSetIfChanged(ref _selectedTimelineMode, value);
    }

    public TimelineViewModel(IScreen screen)
    {
        HostScreen = screen;
    }

}
