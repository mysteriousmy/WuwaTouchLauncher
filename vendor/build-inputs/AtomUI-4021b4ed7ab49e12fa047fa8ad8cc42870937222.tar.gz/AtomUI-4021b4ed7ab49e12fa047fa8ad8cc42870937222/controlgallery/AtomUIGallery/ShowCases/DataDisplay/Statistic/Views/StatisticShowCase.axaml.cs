namespace AtomUIGallery.ShowCases.Statistic;

public partial class StatisticShowCase : GalleryReactiveUserControl<StatisticViewModel>
{
    public const string LanguageId = nameof(StatisticShowCase);

    public StatisticShowCase()
    {
        InitializeComponent();

        this.WhenActivated(disposables =>
        {
            if (DataContext is StatisticViewModel viewModel)
            {
                viewModel.Deadline = DateTime.Now.Add(TimeSpan.FromSeconds(60 * 60 * 24 * 2 + 30));
                viewModel.Before = DateTime.Now.Subtract(TimeSpan.FromSeconds(60 * 60 * 24 * 2 + 30));
                viewModel.TenSecondsLater = DateTime.Now.AddSeconds(10);
            }
        });
    }

}
