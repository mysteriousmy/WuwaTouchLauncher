using AtomUI.Controls;
using ReactiveUI;

namespace AtomUIGallery.ShowCases.Icon;

public class IconViewModel : ReactiveObject, IRoutableViewModel
{
    public static EntityKey ID = "Icon";

    public IScreen HostScreen { get; }

    public string? UrlPathSegment => ID.ToString();

    public IconViewModel(IScreen screen)
    {
        HostScreen = screen;
    }
}
