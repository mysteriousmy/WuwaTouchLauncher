namespace AtomUIGallery.ShowCases.FloatButton;

public partial class FloatButtonShowCase : GalleryReactiveUserControl<FloatButtonViewModel>
{
    public const string LanguageId = nameof(FloatButtonShowCase);

    public FloatButtonShowCase()
    {
        InitializeComponent();
        this.WhenActivated(disposables =>
        {
            if (DataContext is FloatButtonViewModel vm)
            {
                vm.IsOpened = true;
            }
        });
    }

}
